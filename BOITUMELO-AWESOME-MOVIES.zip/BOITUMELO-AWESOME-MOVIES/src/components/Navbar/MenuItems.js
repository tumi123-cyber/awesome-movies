export const MenuItems = [
    {
        title:'Home',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Popular movies',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'about the developer',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Contact Us',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'SignUp',
        url:'#',
        cName:'nav-links-mobile'
    },
]